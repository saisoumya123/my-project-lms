import { FilterAuthorPipe } from './filter-author.pipe';

describe('FilterAuthorPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterAuthorPipe();
    expect(pipe).toBeTruthy();
  });
});
